from flask import Blueprint, render_template
from flask_login import current_user
from models import Contact

main = Blueprint('main', __name__)

@main.route('/')
@login_required
def index():
    contacts = Contact.query.filter_by(user_id=current_user.id).all()
    return render_template('index.html', contacts=contacts)