import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # 2MB file limit

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    number = db.Column(db.String(20), nullable=False)
    details = db.Column(db.Text)
    photo = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/')
def index():
    try:
        search_query = request.args.get('q', '')
        if search_query:
            contacts = Contact.query.filter(
                Contact.name.ilike(f'%{search_query}%') |
                Contact.number.ilike(f'%{search_query}%') |
                Contact.details.ilike(f'%{search_query}%')
            ).all()
        else:
            contacts = Contact.query.all()
        return render_template('index.html', contacts=contacts)
    except Exception as e:
        flash(f"Error loading contacts: {str(e)}", "danger")
        return redirect(url_for('index'))

@app.route('/create', methods=['GET', 'POST'])
def create():
    try:
        if request.method == 'POST':
            name = request.form['name']
            number = request.form['number']
            details = request.form['details']
            photo = request.files['photo']

            photo_path = None
            if photo and photo.filename != '':
                filename = secure_filename(photo.filename)
                photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                photo.save(photo_path)

            contact = Contact(
                name=name,
                number=number,
                details=details,
                photo=photo_path
            )
            db.session.add(contact)
            db.session.commit()
            flash('Contact created successfully!', 'success')
            return redirect(url_for('index'))

        return render_template('create.html')
    except Exception as e:
        flash(f"Error creating contact: {str(e)}", "danger")
        return redirect(url_for('create'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)